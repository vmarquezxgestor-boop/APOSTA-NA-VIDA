# Aposta na Vida – Página de Vendas

Este pacote contém:
- index.html (landing page pronta)
- APOSTA_NA_VIDA_PTBR_VIDEOS_ATIVOS.pdf (livro em PDF)

## Como publicar gratuitamente

### Opção 1 – Netlify
1. Crie uma conta em https://www.netlify.com/ (grátis).
2. Faça login e clique em **Add new site > Deploy manually**.
3. Arraste esta pasta .zip para a área de upload.
4. Pronto! Seu site ficará no ar em alguns segundos, com endereço gratuito tipo https://seusite.netlify.app.

### Opção 2 – GitHub Pages
1. Crie uma conta no GitHub (https://github.com).
2. Crie um repositório chamado `aposta-na-vida`.
3. Envie os arquivos (index.html + PDF).
4. Vá em Settings > Pages > selecione branch `main` e root `/`.
5. Pronto! O site ficará no ar em https://seuusuario.github.io/aposta-na-vida.

### Personalizar domínio próprio (.com ou .com.br)
- Registre em https://registro.br ou outro provedor (~R$40/ano).
- No painel do domínio, aponte DNS para Netlify ou GitHub Pages.
